# ------------------------------------------------------------------------------------------ #
# Title: Assignment06
# Desc: This assignment demonstrates using functions
# with structured error handling
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   Aisling,8/5/2024,Created Script
# ------------------------------------------------------------------------------------------ #

import json

# Define Constants
FILE_NAME: str = 'Enrollments.json'
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:
    1. Register a Student for a Course
    2. Show current data
    3. Save data to a file
    4. Exit the program
-----------------------------------------
'''

# Vars
students: list = []  # a table of student data
menu_choice = ''


# Processing
class FileProcessor:
    """
    A collection of processing layer functions that work with JSON files

    ChangeLog: (Who, When, What)
    Ace,2024-08-05,Created Class
    """

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        """ Reads data from a JSON file into a list of dictionary rows

        :param file_name: (string) with name of file
        :param student_data: (list) you want filled with file data
        :return: (list) of dictionary rows
        """
        try:
            file = open(file_name, "r")
            student_data = json.load(file)
            file.close()
        except FileNotFoundError as e:
            IO.output_error_messages("Text file must exist before running this script!", e)
        except json.JSONDecodeError:
            student_data = []
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        finally:
            if not file.closed:
                file.close()
        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        """ Writes data from a list of dictionary rows to a JSON file

        :param file_name: (string) with name of file
        :param student_data: (list) you want to save to file
        :return: (string) message with result of save
        """
        try:
            file = open(file_name, "w")
            json.dump(student_data, file)
            file.close()
        except TypeError as e:
            IO.output_error_messages("Please check that the data is a valid JSON format", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        finally:
            if not file.closed:
                file.close()


# Input/output functions
class IO:
    """
    A collection of presentation layer functions that manage user input and output

    ChangeLog: (Who, When, What)
    Ace,2024-08-05,Created Class
    """

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        """ This function displays custom error messages to the user

        :param message: (string) with the error message
        :param error: (Exception) object
        :return: None
        """
        print(message, end="\n\n")
        if error is not None:
            print("-- Technical Error Message -- ")
            print(error, error.__doc__, type(error), sep='\n')

    @staticmethod
    def output_menu(menu: str):
        """ This function displays a menu of choices to the user

        :param menu: (string) with the menu text
        :return: None
        """
        print()
        print(menu)
        print()  # Adding extra space to make it look nicer.

    @staticmethod
    def input_menu_choice():
        """ This function gets a menu choice from the user

        :return: (string) with the user's choice
        """
        choice = "0"
        try:
            choice = input("Enter your menu choice number: ")
            if choice not in ("1", "2", "3", "4"):  # Note these are strings
                raise Exception("Please, choose only 1, 2, 3, or 4")
        except Exception as e:
            IO.output_error_messages(e.__str__())

        return choice

    @staticmethod
    def output_student_courses(student_data: list):
        """ This function displays the collected student data to the user

        :param student_data: (list) of dictionary rows
        :return: None
        """
        print()
        print("-" * 50)
        for student in student_data:
            try:
            #    print("DEBUG: student dictionary:", student)  # Debug output
                message = " {} {} is registered for {}."
                print(message.format(student["first_name"], student["last_name"], student["course"]))
            except KeyError as e:
                IO.output_error_messages("Data format error: missing key", e)
        print("-" * 50)
        print()

    @staticmethod
    def input_student_data(student_data: list):
        """ This function gets the first name, last name, and course from the user

        :param student_data: (list) of dictionary rows
        :return: (list) of dictionary rows
        """
        try:
            # Input the data
            student_first_name = input("What is the student's first name? ")
            if not student_first_name.isalpha():
                raise ValueError("The first name should not contain numbers.")

            student_last_name = input("What is the student's last name? ")
            if not student_last_name.isalpha():
                raise ValueError("The last name should not contain numbers.")

            student_course = input("What is the student's course? ")

            student = {"first_name": student_first_name,
                       "last_name": student_last_name,
                       "course": student_course}
            student_data.append(student)

        except ValueError as e:
            IO.output_error_messages("That value is not the correct type of data!", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        return student_data


#  End of function definitions

# Beginning of the main body
students = FileProcessor.read_data_from_file(file_name=FILE_NAME, student_data=students)

while True:
    IO.output_menu(menu=MENU)

    menu_choice = IO.input_menu_choice()

    if menu_choice == "1":  # Get new student data
        students = IO.input_student_data(student_data=students)

        continue

    elif menu_choice == "2":  # Display current student data
        IO.output_student_courses(student_data=students)
        continue

    elif menu_choice == "3":  # Save data in a file
        FileProcessor.write_data_to_file(file_name=FILE_NAME, student_data=students)
        continue

    elif menu_choice == "4":  # End the program
        break  # out of the while loop
